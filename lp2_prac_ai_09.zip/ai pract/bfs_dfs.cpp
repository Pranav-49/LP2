#include<iostream>
#define Max 100
using namespace std;

class Graph {
    int adj[Max][Max];
    int visited[Max];
    int n;

public:
    Graph(int vertices) {
        n = vertices;
        for (int i = 0; i < n; i++) {
            visited[i] = 0;
            for (int j = 0; j < n; j++) {
                adj[i][j] = 0;
            }
        }
    }

    void addedge(int u, int v) {
        adj[u][v] = 1;
        adj[v][u] = 1;
    }

    void dfs(int v) {
        visited[v] = 1;
        cout << v << " ";
        for (int i = 0; i < n; i++) {
            if (adj[v][i] == 1 && !visited[i]) {
                dfs(i);
            }
        }
    }
  void bfs(int start) {
    cout << start << " ";
    int queue[Max], front = 0, rear = 0;
    visited[start] = 1;
    queue[rear++] = start;

    while (front < rear) {
        int curr = queue[front++]; 
        for (int i = 0; i < n; i++) {
            if (adj[curr][i] == 1 && !visited[i]) {
                queue[rear++] = i;
                visited[i] = 1;
                cout << i << " ";
            }
        }
    }
}
void reset_visited() {
    for (int i = 0; i < Max; i++) {
        visited[i] = 0;
    }
}

};

int main() {
    int vertices, edges, u, v, start;
    
    cout << "Enter number of vertices: ";
    cin >> vertices;

    Graph g(vertices);

    cout << "Enter number of edges: ";
    cin >> edges;

    cout << "Enter " << edges << " edges (u v):\n";
    for (int i = 0; i < edges; i++) {
        cin >> u >> v;
        g.addedge(u, v);
    }

    cout << "Enter starting vertex for DFS and Bfs";
    cin >> start;
g.dfs(start);
cout << endl;
g.reset_visited(); 
cout << "Bfs Traversal: ";
g.bfs(start);


    return 0;
}
